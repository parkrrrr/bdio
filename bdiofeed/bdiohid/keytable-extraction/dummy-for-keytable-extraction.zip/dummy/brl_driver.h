#include <string>
#include <vector>
#include <iostream>
struct entry {int group; int id; std::string name;};

void dumptables(std::vector<std::pair<std::string, std::vector<std::vector<entry>>>*> tables) {
   for (auto& tablelist : tables) 
   {
      std::cout << "table " << tablelist->first << " {" << std::endl; 
      for (auto& table : tablelist->second)
      {
	 for (auto& entry : table)
         {
	    std::cout << "entry " << entry.group << " " << entry.id << " " << "[" << entry.name << "]" << std::endl;
         }
      }
      std::cout << "}" << std::endl;
   }
}

#define BEGIN_KEY_NAME_TABLE(name) std::vector<entry> table_ ## name = { 
#define END_KEY_NAME_TABLE };
#define KEY_GROUP_ENTRY(number,name) {number, -1, name}
#define KEY_NAME_ENTRY(number,name) {0, number, name}
#define BEGIN_KEY_NAME_TABLES(name) std::vector<std::vector<entry>> model_ ## name = {
#define KEY_NAME_SUBTABLE(name,count) std::vector<entry>(table_##name.begin() + (table_##name.size() - count), table_##name.end())
#define KEY_NAME_TABLE(name) table_ ## name  
#define END_KEY_NAME_TABLES } ;
#define DEFINE_KEY_TABLE(name) std::pair<std::string, std::vector<std::vector<entry>>> pair_ ## name = \
std::make_pair<std::string, std::vector<std::vector<entry>>>(#name, std::move(model_##name));
#define BEGIN_KEY_TABLE_LIST int main() { std::vector<std::pair<std::string, std::vector<std::vector<entry>>>*> all={
#define KEY_TABLE_DEFINITION(name) pair_ ## name 
#define END_KEY_TABLE_LIST }; dumptables(all); return 0;} 

#define BRL_KEY_GROUP(drv,grp) drv ## _GRP_ ## grp
#define BRL_KEY_NAME(drv,grp,key) drv ## _ ## grp ## _ ## key

#define BRL_KEY_GROUP_ENTRY(drv,grp,nam) KEY_GROUP_ENTRY(BRL_KEY_GROUP(drv, grp), nam)
#define BRL_KEY_NUMBER_ENTRY(drv,grp,num,nam) {BRL_KEY_GROUP(drv,grp), num, nam}
#define BRL_KEY_NAME_ENTRY(drv,grp,key,nam) BRL_KEY_NUMBER_ENTRY(drv, grp, BRL_KEY_NAME(drv, grp, key), nam)

#define KEY_ENTRY(s,t,k,n) {EU_GRP_##s, EU_##t##_##k,n}
#define PACKED
 
